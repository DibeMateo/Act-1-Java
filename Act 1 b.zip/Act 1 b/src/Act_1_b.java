public class Act_1_b {

    public static void main(String[] args) {
        Car myCar = new Car();
        myCar.AddDoor();
        System.out.println(myCar.doors);
    }

    public static int suma(int a, int b) {
        return a + b;
    }
}

class Car {
    public int doors = 0;
    public void AddDoor() {
        this.doors = ++;
    }
}

